#pragma once
#include <JuceHeader.h>

// Lightweight dual-head delay-line shifter. Intended as a low-latency first-pass shifter;
// strong shifts can produce artifacts compared with a production phase-vocoder/PSOLA engine.
class DelayPitchShifter
{
public:
    void prepare(double sampleRate, int channels, int maxBlock);
    void reset();
    void process(juce::AudioBuffer<float>& buffer, float ratio);
private:
    juce::AudioBuffer<float> delay;
    std::vector<int> write;
    double sr = 44100.0;
    float phase = 0.0f;
    int delaySize = 0;
};
