#include "PitchDetector.h"

void PitchDetector::prepare(double sampleRate, int)
{
    sr = sampleRate;
    const int size = 4096;
    history.setSize(1, size);
    history.clear();
    frame.resize(size); difference.resize(size / 2); cmnd.resize(size / 2);
    reset();
}
void PitchDetector::reset() { history.clear(); writePos = filled = 0; lastHz = 0.0f; }
float PitchDetector::process(const float* input, int n)
{
    const int cap = history.getNumSamples();
    for (int i = 0; i < n; ++i) { history.setSample(0, writePos, input[i]); writePos = (writePos + 1) % cap; filled = juce::jmin(cap, filled + 1); }
    if (filled < 2048) return lastHz;
    for (int i = 0; i < 2048; ++i) frame[(size_t)i] = history.getSample(0, (writePos + cap - 2048 + i) % cap);
    // Remove DC and apply a Hann window.
    float mean = 0.0f; for (int i = 0; i < 2048; ++i) mean += frame[(size_t)i]; mean /= 2048.0f;
    for (int i = 0; i < 2048; ++i) frame[(size_t)i] = (frame[(size_t)i] - mean) * (0.5f - 0.5f * std::cos(juce::MathConstants<float>::twoPi * i / 2047.0f));
    const int minLag = juce::jmax(2, (int)(sr / 1000.0));
    const int maxLag = juce::jmin(1023, (int)(sr / 65.0));
    difference[0] = 0.0f;
    for (int tau = 1; tau <= maxLag; ++tau) { double sum = 0.0; for (int j = 0; j < 2048 - maxLag; ++j) { const float d = frame[(size_t)j] - frame[(size_t)(j + tau)]; sum += d * d; } difference[(size_t)tau] = (float)sum; }
    cmnd[0] = 1.0f; double running = 0.0;
    for (int tau = 1; tau <= maxLag; ++tau) { running += difference[(size_t)tau]; cmnd[(size_t)tau] = running > 0.0 ? (float)(difference[(size_t)tau] * tau / running) : 1.0f; }
    int best = -1; constexpr float threshold = 0.14f;
    for (int tau = minLag; tau <= maxLag; ++tau) if (cmnd[(size_t)tau] < threshold) { while (tau + 1 <= maxLag && cmnd[(size_t)(tau + 1)] < cmnd[(size_t)tau]) ++tau; best = tau; break; }
    if (best < 0) { float v = 1.0f; for (int tau = minLag; tau <= maxLag; ++tau) if (cmnd[(size_t)tau] < v) { v = cmnd[(size_t)tau]; best = tau; } if (v > 0.35f) return lastHz; }
    const float a = cmnd[(size_t)juce::jmax(minLag, best - 1)], b = cmnd[(size_t)best], c = cmnd[(size_t)juce::jmin(maxLag, best + 1)];
    const float denom = a - 2.0f * b + c;
    const float offset = std::abs(denom) > 1.0e-9f ? 0.5f * (a - c) / denom : 0.0f;
    const float hz = (float)(sr / (best + juce::jlimit(-0.5f, 0.5f, offset)));
    if (hz >= 65.0f && hz <= 1000.0f) lastHz = lastHz > 0.0f ? 0.65f * lastHz + 0.35f * hz : hz;
    return lastHz;
}
