#include "DelayPitchShifter.h"
void DelayPitchShifter::prepare(double sampleRate, int channels, int)
{
    sr = sampleRate; delaySize = juce::jmax(2048, (int)(sr * 0.12));
    delay.setSize(channels, delaySize); delay.clear(); write.assign((size_t)channels, 0); reset();
}
void DelayPitchShifter::reset() { delay.clear(); std::fill(write.begin(), write.end(), 0); phase = 0.0f; }
void DelayPitchShifter::process(juce::AudioBuffer<float>& b, float ratio)
{
    ratio = juce::jlimit(0.5f, 2.0f, ratio);
    if (std::abs(ratio - 1.0f) < 0.0001f) return;
    const float depth = (float)(sr * 0.045);
    const float increment = (1.0f - ratio) / depth;
    for (int ch = 0; ch < b.getNumChannels(); ++ch) {
        auto* x = b.getWritePointer(ch); auto* d = delay.getWritePointer(juce::jmin(ch, delay.getNumChannels()-1)); int wp = write[(size_t)ch]; float p = phase;
        for (int i = 0; i < b.getNumSamples(); ++i) {
            d[wp] = x[i];
            float p2 = p + 0.5f; if (p2 >= 1.0f) p2 -= 1.0f;
            const float d1 = 32.0f + p * depth, d2 = 32.0f + p2 * depth;
            auto read = [&](float delaySamples) { float pos = (float)wp - delaySamples; while (pos < 0.0f) pos += delaySize; const int i0 = (int)pos; const int i1 = (i0 + 1) % delaySize; const float f = pos - i0; return d[i0] + f * (d[i1] - d[i0]); };
            const float w1 = 0.5f - 0.5f * std::cos(juce::MathConstants<float>::twoPi * p);
            const float w2 = 1.0f - w1;
            x[i] = read(d1) * w1 + read(d2) * w2;
            wp = (wp + 1) % delaySize; p += increment; p -= std::floor(p);
        }
        write[(size_t)ch] = wp;
        if (ch == 0) phase = p;
    }
}
