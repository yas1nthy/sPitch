#pragma once
#include <JuceHeader.h>

class PitchDetector
{
public:
    void prepare(double sampleRate, int maxBlockSize);
    float process(const float* input, int numSamples);
    void reset();
private:
    juce::AudioBuffer<float> history;
    int writePos = 0;
    int filled = 0;
    double sr = 44100.0;
    float lastHz = 0.0f;
    std::vector<float> frame, difference, cmnd;
};
