@echo off
setlocal EnableExtensions
cd /d "%~dp0"

echo =============================================
echo            sPitch Windows Builder
echo =============================================

where cmake >nul 2>nul || (echo ERROR: CMake 3.22+ not found. Install CMake and add it to PATH.& pause & exit /b 1)
where git >nul 2>nul || (echo ERROR: Git not found. Install Git for Windows and add it to PATH.& pause & exit /b 1)

if not exist "build" mkdir build
cmake -S . -B build -G "Visual Studio 17 2022" -A x64
if errorlevel 1 (echo ERROR: CMake configure failed. Check internet access and Visual Studio C++ workload.& pause & exit /b 1)

cmake --build build --config Release --target sPitch_VST3 sPitch_Standalone --parallel
if errorlevel 1 (echo ERROR: Compilation failed.& pause & exit /b 1)

set "ISCC="
where ISCC.exe >nul 2>nul && set "ISCC=ISCC.exe"
if not defined ISCC if exist "%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe" set "ISCC=%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe"
if not defined ISCC if exist "%ProgramFiles%\Inno Setup 6\ISCC.exe" set "ISCC=%ProgramFiles%\Inno Setup 6\ISCC.exe"
if not defined ISCC (echo ERROR: Inno Setup 6 not found. Install it from https://jrsoftware.org/isinfo.php.& pause & exit /b 1)

"%ISCC%" installer\sPitch.iss
if errorlevel 1 (echo ERROR: Installer packaging failed.& pause & exit /b 1)

echo.
echo SUCCESS. Installer: installer\Output\sPitch-Setup-0.1.0-x64.exe
pause
