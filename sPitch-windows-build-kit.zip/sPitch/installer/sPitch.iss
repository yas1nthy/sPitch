#define AppName "sPitch"
#define AppVersion "0.1.0"
#define AppPublisher "sPitch Audio"
#define PluginBundle "..\build\sPitch_artefacts\Release\VST3\sPitch.vst3"
#define StandaloneExe "..\build\sPitch_artefacts\Release\Standalone\sPitch.exe"

[Setup]
AppId={{A9E7A84A-3C89-4B1D-A5D9-7B2B3A5D0F11}
AppName={#AppName}
AppVersion={#AppVersion}
AppPublisher={#AppPublisher}
DefaultDirName={autopf}\sPitch
DefaultGroupName=sPitch
OutputDir=Output
OutputBaseFilename=sPitch-Setup-{#AppVersion}-x64
ArchitecturesInstallIn64BitMode=x64
ArchitecturesAllowed=x64
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
PrivilegesRequired=admin
UninstallDisplayIcon={app}\sPitch.exe

[Files]
Source: "{#PluginBundle}\*"; DestDir: "{commoncf}\VST3\sPitch.vst3"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "{#StandaloneExe}"; DestDir: "{app}"; Flags: ignoreversion; Check: FileExists(ExpandConstant('{#StandaloneExe}'))

[Icons]
Name: "{group}\sPitch (Standalone)"; Filename: "{app}\sPitch.exe"; Check: FileExists(ExpandConstant('{app}\sPitch.exe'))
Name: "{group}\Uninstall sPitch"; Filename: "{uninstallexe}"

[Run]
Filename: "{app}\sPitch.exe"; Description: "Launch sPitch"; Flags: postinstall nowait skipifsilent; Check: FileExists(ExpandConstant('{app}\sPitch.exe'))

[Code]
function InitializeSetup(): Boolean;
begin
  if not DirExists(ExpandConstant('{#PluginBundle}')) then
  begin
    MsgBox('The VST3 build was not found. Run build-windows.bat first and make sure compilation succeeds.', mbError, MB_OK);
    Result := False;
  end
  else
    Result := True;
end;
