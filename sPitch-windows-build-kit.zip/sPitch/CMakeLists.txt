cmake_minimum_required(VERSION 3.22)
project(sPitch VERSION 0.1.0)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

include(FetchContent)
FetchContent_Declare(JUCE GIT_REPOSITORY https://github.com/juce-framework/JUCE.git GIT_TAG 8.0.6 GIT_SHALLOW TRUE)
FetchContent_MakeAvailable(JUCE)

juce_add_plugin(sPitch
    COMPANY_NAME "sPitch Audio"
    BUNDLE_ID "audio.spitch.plugin"
    PLUGIN_MANUFACTURER_CODE Spch
    PLUGIN_CODE Sp01
    FORMATS VST3 Standalone
    PRODUCT_NAME "sPitch"
    DESCRIPTION "Real-time vocal pitch correction"
    IS_SYNTH FALSE
    NEEDS_MIDI_INPUT TRUE
    NEEDS_MIDI_OUTPUT FALSE
    IS_MIDI_EFFECT FALSE
    EDITOR_WANTS_KEYBOARD_FOCUS TRUE
    COPY_PLUGIN_AFTER_BUILD FALSE
)

target_sources(sPitch PRIVATE
    Source/PluginProcessor.cpp
    Source/PluginProcessor.h
    Source/PluginEditor.cpp
    Source/PluginEditor.h
    DSP/PitchDetector.h
    DSP/PitchDetector.cpp
    DSP/DelayPitchShifter.h
    DSP/DelayPitchShifter.cpp
)
target_compile_definitions(sPitch PUBLIC JUCE_WEB_BROWSER=0 JUCE_USE_CURL=0 JUCE_VST3_CAN_REPLACE_VST2=0)
target_link_libraries(sPitch PRIVATE juce::juce_audio_utils juce::juce_dsp PUBLIC juce::juce_recommended_config_flags juce::juce_recommended_lto_flags juce::juce_recommended_warning_flags)
