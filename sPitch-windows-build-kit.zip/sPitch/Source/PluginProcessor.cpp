#include "PluginProcessor.h"
#include "PluginEditor.h"

juce::AudioProcessorValueTreeState::ParameterLayout SPitchAudioProcessor::createParameters()
{
    using namespace juce; std::vector<std::unique_ptr<RangedAudioParameter>> p;
    auto choice = [](String id, String name, StringArray values, int def) { return std::make_unique<AudioParameterChoice>(ParameterID{id,1}, name, values, def); };
    auto f = [](String id, String name, float lo, float hi, float def, String unit = String{}) { return std::make_unique<AudioParameterFloat>(ParameterID{id,1}, name, NormalisableRange<float>(lo,hi,0.01f), def, unit); };
    p.push_back(choice("key","Key",{"C","C#","D","D#","E","F","F#","G","G#","A","A#","B"},0));
    p.push_back(choice("scale","Scale",{"Major","Minor","Harmonic Minor","Melodic Minor","Chromatic"},1));
    p.push_back(choice("mode","Mode",{"Natural","Modern","Hard Tune"},1));
    p.push_back(f("retune","Retune Speed",0,500,20," ms"));
    p.push_back(f("strength","Correction Strength",0,100,100," %"));
    p.push_back(f("humanize","Humanize",0,100,30," %"));
    p.push_back(f("flex","Flex Tune",0,100,15," %"));
    p.push_back(f("formant","Formant Shift",-12,12,0," st"));
    p.push_back(f("mix","Dry / Wet",0,100,100," %"));
    p.push_back(f("input","Input Gain",-24,24,0," dB"));
    p.push_back(f("output","Output Gain",-24,24,0," dB"));
    p.push_back(std::make_unique<AudioParameterBool>(ParameterID{"formantOn",1},"Formant Preserve",true));
    p.push_back(std::make_unique<AudioParameterBool>(ParameterID{"enabled",1},"Enabled",true));
    return {p.begin(),p.end()};
}
SPitchAudioProcessor::SPitchAudioProcessor() : AudioProcessor(BusesProperties().withInput("Input",AudioChannelSet::stereo(),true).withOutput("Output",AudioChannelSet::stereo(),true)), apvts(*this,nullptr,"sPitchState",createParameters()) {}
bool SPitchAudioProcessor::isBusesLayoutSupported(const BusesLayout& l) const { auto in=l.getMainInputChannelSet(), out=l.getMainOutputChannelSet(); return in==out && (in==juce::AudioChannelSet::mono() || in==juce::AudioChannelSet::stereo()); }
void SPitchAudioProcessor::prepareToPlay(double sr,int maxBlock) { sampleRate=sr; detector.prepare(sr,maxBlock); shifter.prepare(sr,getTotalNumOutputChannels(),maxBlock); monoScratch.setSize(1,maxBlock); dryBuffer.setSize(getTotalNumOutputChannels(),maxBlock); smoothedRatio=1.0f; }
void SPitchAudioProcessor::releaseResources() { detector.reset(); shifter.reset(); }
void SPitchAudioProcessor::processBlock(juce::AudioBuffer<float>& buffer,juce::MidiBuffer& midi)
{
    juce::ScopedNoDenormals noDenormals;
    for (const auto metadata : midi) if (metadata.getMessage().isNoteOn()) midiTarget=metadata.getMessage().getNoteNumber(); else if (metadata.getMessage().isAllNotesOff() || metadata.getMessage().isNoteOff()) midiTarget=-1;
    const int n=buffer.getNumSamples(), ch=buffer.getNumChannels();
    float inPeak=0; for(int c=0;c<ch;++c) inPeak=juce::jmax(inPeak,buffer.getMagnitude(c,0,n)); inputLevel.store(inPeak);
    const float inGain=juce::Decibels::decibelsToGain(apvts.getRawParameterValue("input")->load());
    for(int c=0;c<ch;++c) buffer.applyGain(c,0,n,inGain);
    if(!apvts.getRawParameterValue("enabled")->load()) { outputLevel.store(inPeak); return; }
    auto* mono=monoScratch.getWritePointer(0); for(int i=0;i<n;++i){ float s=0; for(int c=0;c<ch;++c)s+=buffer.getSample(c,i); mono[i]=s/(float)ch; }
    const float hz=detector.process(mono,n); detectedHz.store(hz);
    if(hz>0.0f)
    {
        const float midiNote=69.0f+12.0f*std::log2(hz/440.0f); detectedMidi.store(midiNote);
        const int key=(int)apvts.getRawParameterValue("key")->load(); const int scale=(int)apvts.getRawParameterValue("scale")->load();
        static const bool scales[5][12]={{1,0,1,0,1,1,0,1,0,1,0,1},{1,0,1,1,0,1,0,1,1,0,1,0},{1,0,1,1,0,1,0,1,1,0,0,1},{1,0,1,1,0,1,0,1,0,1,0,1},{1,1,1,1,1,1,1,1,1,1,1,1}};
        int target=midiTarget>=0?midiTarget:(int)std::round(midiNote); float best=1.0e9f;
        if(midiTarget<0) for(int candidate=(int)std::floor(midiNote)-2;candidate<=(int)std::ceil(midiNote)+2;++candidate) { int pc=(candidate-key+120)%12; if(scales[scale][pc]) { float d=std::abs(candidate-midiNote); if(d<best){best=d;target=candidate;} } }
        const float flex=apvts.getRawParameterValue("flex")->load()/100.0f; const float strength=apvts.getRawParameterValue("strength")->load()/100.0f;
        float correction=juce::jlimit(0.0f,1.0f,(1.0f-flex)*strength);
        float retune=apvts.getRawParameterValue("retune")->load(); int mode=(int)apvts.getRawParameterValue("mode")->load(); if(mode==0) retune=juce::jmax(retune,90.0f); if(mode==2) retune=0.0f;
        const float desired=std::pow(2.0f,((float)target-midiNote)*correction/12.0f);
        const float alpha=retune<=0.1f?1.0f:1.0f-std::exp(-(float)n/(float)(sampleRate*(retune/1000.0f)));
        smoothedRatio+=alpha*(desired-smoothedRatio);
        if(mode==0) smoothedRatio=1.0f+(smoothedRatio-1.0f)*0.75f;
        const float human=apvts.getRawParameterValue("humanize")->load()/100.0f;
        const float ratio=1.0f+(smoothedRatio-1.0f)*(1.0f-human*0.25f);
        for(int c=0;c<ch;++c) dryBuffer.copyFrom(c,0,buffer,c,0,n);
        shifter.process(buffer,ratio);
        const float mix=apvts.getRawParameterValue("mix")->load()/100.0f;
        for(int c=0;c<ch;++c) for(int i=0;i<n;++i) buffer.setSample(c,i,dryBuffer.getSample(c,i)*(1.0f-mix)+buffer.getSample(c,i)*mix);
    }
    const float outGain=juce::Decibels::decibelsToGain(apvts.getRawParameterValue("output")->load()); buffer.applyGain(outGain);
    float peak=0; for(int c=0;c<ch;++c) peak=juce::jmax(peak,buffer.getMagnitude(c,0,n)); outputLevel.store(peak);
}
void SPitchAudioProcessor::getStateInformation(juce::MemoryBlock& d){auto s=apvts.copyState();std::unique_ptr<juce::XmlElement>x(s.createXml());copyXmlToBinary(*x,d);}
void SPitchAudioProcessor::setStateInformation(const void* data,int size){std::unique_ptr<juce::XmlElement>x(getXmlFromBinary(data,size));if(x&&x->hasTagName(apvts.state.getType()))apvts.replaceState(juce::ValueTree::fromXml(*x));}
juce::AudioProcessorEditor* SPitchAudioProcessor::createEditor(){return new SPitchAudioProcessorEditor(*this);}
juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter(){return new SPitchAudioProcessor();}
