#include "PluginEditor.h"

void SPitchAudioProcessorEditor::NeonLook::drawRotarySlider(juce::Graphics& g,int x,int y,int w,int h,float pos,float start,float end,juce::Slider&)
{
    auto r=juce::Rectangle<float>((float)x+8,(float)y+8,(float)w-16,(float)h-16).reduced(8); auto c=r.getCentre(); float radius=juce::jmin(r.getWidth(),r.getHeight())*0.5f;
    g.setColour(juce::Colour(0xff080d10)); g.fillEllipse(r);
    g.setColour(juce::Colour(0xff263238)); g.drawEllipse(r,2.0f);
    juce::Path arc; arc.addCentredArc(c.x,c.y,radius+5,radius+5,0,start,start+(end-start)*pos,true);
    g.setColour(juce::Colour(0xff16e6d1)); g.strokePath(arc,juce::PathStrokeType(4.0f,juce::PathStrokeType::curved,juce::PathStrokeType::rounded));
    const float a=start+(end-start)*pos; juce::Point<float> p(c.x+std::sin(a)*(radius-7),c.y-std::cos(a)*(radius-7));
    g.setColour(juce::Colours::white); g.drawLine(c.x,c.y,p.x,p.y,3.5f); g.setColour(juce::Colour(0xff10191d)); g.fillEllipse(c.x-5,c.y-5,10,10);
}
SPitchAudioProcessorEditor::SPitchAudioProcessorEditor(SPitchAudioProcessor& p):AudioProcessorEditor(&p),processor(p)
{
    setLookAndFeel(&look); setSize(1000,650);
    logo.setText("≋  sPitch",juce::dontSendNotification); logo.setFont(juce::Font(juce::FontOptions(31,juce::Font::bold))); logo.setColour(juce::Label::textColourId,juce::Colour(0xffe9ffff)); addAndMakeVisible(logo);
    auto setupCombo=[&](juce::ComboBox& b){b.setColour(juce::ComboBox::backgroundColourId,juce::Colour(0xff11191d));b.setColour(juce::ComboBox::textColourId,juce::Colours::white);b.setColour(juce::ComboBox::outlineColourId,juce::Colour(0xff285b5b));addAndMakeVisible(b);};
    for(int i=0;i<12;++i) key.addItem(juce::StringArray{"C","C#","D","D#","E","F","F#","G","G#","A","A#","B"][i],i+1);
    scale.addItemList({"Major","Minor","Harmonic Minor","Melodic Minor","Chromatic"},1); mode.addItemList({"Natural","Modern","Hard Tune"},1);
    setupCombo(key);setupCombo(scale);setupCombo(mode);
    keyA=std::make_unique<juce::AudioProcessorValueTreeState::ComboBoxAttachment>(p.apvts,"key",key); scaleA=std::make_unique<juce::AudioProcessorValueTreeState::ComboBoxAttachment>(p.apvts,"scale",scale); modeA=std::make_unique<juce::AudioProcessorValueTreeState::ComboBoxAttachment>(p.apvts,"mode",mode);
    auto setupSlider=[&](juce::Slider& s,juce::String name){s.setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag);s.setTextBoxStyle(juce::Slider::TextBoxBelow,false,100,27);s.setColour(juce::Slider::textBoxTextColourId,juce::Colours::white);s.setColour(juce::Slider::textBoxOutlineColourId,juce::Colour(0xff285b5b));s.setName(name);addAndMakeVisible(s);};
    setupSlider(retune,"Retune Speed");setupSlider(strength,"Correction Strength");setupSlider(humanize,"Humanize");setupSlider(flex,"Flex Tune");setupSlider(mix,"Dry / Wet");
    retuneA=std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(p.apvts,"retune",retune);strengthA=std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(p.apvts,"strength",strength);humanA=std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(p.apvts,"humanize",humanize);flexA=std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(p.apvts,"flex",flex);mixA=std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(p.apvts,"mix",mix);
    power.setColour(juce::ToggleButton::textColourId,juce::Colours::white);addAndMakeVisible(power);powerA=std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment>(p.apvts,"enabled",power);
    note.setJustificationType(juce::Justification::centred);note.setFont(juce::Font(juce::FontOptions(48,juce::Font::bold)));note.setColour(juce::Label::textColourId,juce::Colour(0xff19e8d2));addAndMakeVisible(note);
    cents.setJustificationType(juce::Justification::centred);cents.setColour(juce::Label::textColourId,juce::Colour(0xffa6c4c3));addAndMakeVisible(cents);
    presetLabel.setText("PRESET  /  Default",juce::dontSendNotification);presetLabel.setColour(juce::Label::textColourId,juce::Colour(0xff9bb4b5));addAndMakeVisible(presetLabel);
    startTimerHz(20);
}
void SPitchAudioProcessorEditor::timerCallback(){float m=processor.getDetectedMidi();if(m>=0){int n=(int)std::round(m);note.setText(juce::MidiMessage::getMidiNoteName(n,true,true,3),juce::dontSendNotification);cents.setText(juce::String((m-n)*100.0f,1)+" cents",juce::dontSendNotification);}else{note.setText("—",juce::dontSendNotification);cents.setText("Waiting for vocal input",juce::dontSendNotification);} }
void SPitchAudioProcessorEditor::paint(juce::Graphics& g)
{
    g.fillAll(juce::Colour(0xff080b0d)); auto b=getLocalBounds().toFloat();
    g.setGradientFill(juce::ColourGradient(juce::Colour(0xff1a2428),0,0,juce::Colour(0xff090c0e),0,b.getHeight(),false));g.fillRect(b);
    g.setColour(juce::Colour(0xff1c3437));g.drawRect(10,10,getWidth()-20,getHeight()-20,1);
    g.setColour(juce::Colour(0xff193e40));g.drawLine(30,86,getWidth()-30,86,1);
    g.setColour(juce::Colour(0xff16dcca));g.setFont(14);g.drawText("PITCH MONITOR",365,110,270,22,juce::Justification::centred);
    g.setColour(juce::Colour(0xff607779));g.drawText("RETUNE SPEED",75,190,210,22,juce::Justification::centred);
    g.drawText("CORRECTION",395,190,210,22,juce::Justification::centred);
    g.drawText("HUMANIZE",715,190,210,22,juce::Justification::centred);
    // Minimal piano keyboard inspired by the supplied reference.
    const int left=28, top=535, width=getWidth()-56, whiteW=width/21; g.setColour(juce::Colour(0xffdce5e5));
    for(int i=0;i<21;++i){juce::Rectangle<float> r((float)(left+i*whiteW),(float)top,(float)whiteW-1,78);g.fillRect(r);g.setColour(juce::Colour(0xff4b5b5d));g.drawRect(r,1);g.setColour(juce::Colour(0xffdce5e5));}
    const int blackAfter[]={0,1,3,4,5,7,8,10,11,12,14,15,17,18,19};g.setColour(juce::Colour(0xff080a0b));for(int i:blackAfter){int xx=left+(i+1)*whiteW-whiteW/3;g.fillRoundedRectangle((float)xx,(float)top,(float)(whiteW*0.64f),52,3);g.setColour(juce::Colour(0xff314244));g.drawRoundedRectangle((float)xx,(float)top,(float)(whiteW*0.64f),52,3,1);g.setColour(juce::Colour(0xff080a0b));}
    g.setColour(juce::Colour(0xff28494b));g.drawLine(30,520,getWidth()-30,520,1);
}
void SPitchAudioProcessorEditor::resized()
{
    logo.setBounds(35,22,230,52);presetLabel.setBounds(270,25,180,45);key.setBounds(485,25,85,42);scale.setBounds(580,25,155,42);mode.setBounds(745,25,150,42);power.setBounds(900,30,85,32);
    retune.setBounds(65,215,230,260);strength.setBounds(385,215,230,260);humanize.setBounds(705,215,230,260);
    note.setBounds(365,125,270,60);cents.setBounds(365,168,270,25);flex.setBounds(60,470,180,58);mix.setBounds(760,470,180,58);
}
