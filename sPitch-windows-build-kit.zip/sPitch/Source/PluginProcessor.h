#pragma once
#include <JuceHeader.h>
#include "../DSP/PitchDetector.h"
#include "../DSP/DelayPitchShifter.h"

class SPitchAudioProcessor : public juce::AudioProcessor
{
public:
    SPitchAudioProcessor();
    ~SPitchAudioProcessor() override = default;
    void prepareToPlay(double, int) override;
    void releaseResources() override;
    void processBlock(juce::AudioBuffer<float>&, juce::MidiBuffer&) override;
    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }
    const juce::String getName() const override { return JucePlugin_Name; }
    bool acceptsMidi() const override { return true; }
    bool producesMidi() const override { return false; }
    bool isMidiEffect() const override { return false; }
    double get tailLengthSeconds() const override { return 0.1; }
    int getNumPrograms() override { return 1; }
    int getCurrentProgram() override { return 0; }
    void setCurrentProgram(int) override {}
    const juce::String getProgramName(int) override { return {}; }
    void changeProgramName(int, const juce::String&) override {}
    void getStateInformation(juce::MemoryBlock&) override;
    void setStateInformation(const void*, int) override;
    bool isBusesLayoutSupported(const BusesLayout&) const override;
    juce::AudioProcessorValueTreeState apvts;
    float getDetectedHz() const { return detectedHz.load(); }
    float getDetectedMidi() const { return detectedMidi.load(); }
    float getInputLevel() const { return inputLevel.load(); }
    float getOutputLevel() const { return outputLevel.load(); }
    static juce::AudioProcessorValueTreeState::ParameterLayout createParameters();
private:
    PitchDetector detector;
    DelayPitchShifter shifter;
    juce::AudioBuffer<float> monoScratch, dryBuffer;
    std::atomic<float> detectedHz{0}, detectedMidi{-1}, inputLevel{0}, outputLevel{0};
    double sampleRate = 44100.0;
    float smoothedRatio = 1.0f;
    int midiTarget = -1;
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(SPitchAudioProcessor)
};
