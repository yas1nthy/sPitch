#pragma once
#include <JuceHeader.h>
#include "PluginProcessor.h"

class SPitchAudioProcessorEditor : public juce::AudioProcessorEditor, private juce::Timer
{
public:
    explicit SPitchAudioProcessorEditor(SPitchAudioProcessor&);
    ~SPitchAudioProcessorEditor() override = default;
    void paint(juce::Graphics&) override;
    void resized() override;
private:
    void timerCallback() override;
    struct NeonLook : juce::LookAndFeel_V4 {
        void drawRotarySlider(juce::Graphics&,int,int,int,int,float,float,float,juce::Slider&) override;
    } look;
    SPitchAudioProcessor& processor;
    juce::ComboBox key, scale, mode;
    juce::Label logo, note, cents, presetLabel;
    juce::Slider retune, strength, humanize, flex, mix;
    juce::ToggleButton power {"POWER"};
    std::unique_ptr<juce::AudioProcessorValueTreeState::ComboBoxAttachment> keyA,scaleA,modeA;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> retuneA,strengthA,humanA,flexA,mixA;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment> powerA;
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(SPitchAudioProcessorEditor)
};
