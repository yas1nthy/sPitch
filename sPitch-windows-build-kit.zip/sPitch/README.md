# sPitch — JUCE VST3 project (prototype v0.1)

This repository is a **working-source prototype**, not a finished commercial Auto-Tune replacement. It contains a JUCE audio plug-in, APVTS parameters (DAW automation/state), a real-time YIN-style monophonic pitch detector, MIDI note targeting, key/scale target selection, retune smoothing, a dual-head delay-line pitch shifter, and a custom editor based on the supplied sPitch reference.

## Important audio-engine limitations

The included shifter is a lightweight delay-line prototype. It is useful for validating the plug-in architecture and controls, but it is **not yet transparent or artifact-free enough for commercial vocal production**, especially for large shifts, polyphonic input, breathy vocals, and fast transients. It does not yet implement PSOLA or a phase-coherent STFT phase vocoder. Formant Shift/Preserve controls, manual note drawing, custom scales, A/B, preset browser, and full pitch graph are intentionally not presented as implemented features. The `Formant Shift` parameter is reserved in the state layout only and currently has no DSP effect.

The pitch detector currently performs a full analysis on each audio callback; for production use it should be moved to a bounded-rate analysis cadence and profiled at 44.1–192 kHz. The shifter introduces algorithmic delay that is not yet compensated/reported to the host. Treat this as an engineering foundation for the next DSP iteration, not a release-ready plug-in.

## Build

Requirements: Windows 10/11 x64, Visual Studio 2022 with C++ workload, CMake 3.22+, Git, and an internet connection for the first configure (JUCE 8.0.6 is fetched by CMake).

```powershell
cmake -S . -B build -G "Visual Studio 17 2022" -A x64
cmake --build build --config Release --target sPitch_VST3
```

The VST3 bundle is normally produced under `build/sPitch_artefacts/Release/VST3/`.

For a standalone test build:

```powershell
cmake --build build --config Release --target sPitch_Standalone
```

## Install

Copy `sPitch.vst3` into:

`C:\Program Files\Common Files\VST3\`

Restart/rescan plug-ins in FL Studio, Ableton Live, Cubase, Reaper, or Studio One. In FL Studio use **Options → Manage plugins → Find installed plugins**.

## Current controls

- Key and Scale: major, minor, harmonic minor, melodic minor, chromatic.
- Mode: Natural / Modern / Hard Tune.
- Retune Speed, Correction Strength, Humanize, Flex Tune, Dry/Wet.
- Input/Output gain parameters are exposed to DAW automation/state (UI controls will be added in the next UI pass).
- MIDI note-on can set the target note while held.
- Pitch monitor shows detected note and approximate cents offset.

## Architecture

- `Source/PluginProcessor.*` — JUCE processor, parameter tree, MIDI, host state.
- `Source/PluginEditor.*` — minimal dark/cyan editor and piano-key visual.
- `DSP/PitchDetector.*` — YIN cumulative-mean-normalized difference pitch detector.
- `DSP/DelayPitchShifter.*` — dual-head delay-line shifter prototype.

## Next production milestones

1. Replace the prototype shifter with a tested phase-vocoder/PSOLA engine and formant preservation.
2. Add latency reporting/compensation and transient-aware voiced/unvoiced handling.
3. Move pitch analysis to a bounded-rate worker with lock-free result exchange.
4. Add manual pitch editor, true custom scale mask, A/B, preset management, and complete metering.
5. Add automated DSP tests (F0 accuracy, cents error, aliasing, latency, denormal handling, long-run stability) and benchmark on supported sample rates/block sizes.
